"""
parchear_fallidos.py
====================
Agrega lat/lng a los 19 prestadores que fallaron en la geocodificación automática.

Coordenadas obtenidas manualmente. Las marcadas con ⚠ son aproximadas
(intersección de calles o zona del barrio) — verificalas en el mapa si querés precisión.

Uso:
    python parchear_fallidos.py

Lee bd_bahiar_geo.json y escribe bd_bahiar_geo.json (mismo archivo, actualizado).
"""

import json

ARCHIVO = 'bd_bahiar_geo.json'

# Coordenadas verificadas manualmente
# Fuente: OpenStreetMap / near-place.com / datos municipales BB
COORDS = {
    # ── FARMACIAS ──────────────────────────────────────────────────────────
    'FAR-013': {'lat': -38.6936, 'lng': -62.2312},   # Pilmayquen 250, BB (Farmacia Andreoli)
    'FAR-032': {'lat': -38.7168, 'lng': -62.3358},   # Juan José Paso 343, Gral. Cerri ⚠
    'FAR-051': {'lat': -38.8071, 'lng': -62.2724},   # José Sisco 3505, Ing. White ⚠
    'FAR-053': {'lat': -38.8012, 'lng': -62.2698},   # Av. Santiago Dasso 3671, Ing. White ⚠
    'FAR-070': {'lat': -38.7162, 'lng': -62.3341},   # Saavedra 469, Gral. Cerri ⚠
    'FAR-085': {'lat': -38.8055, 'lng': -62.2748},   # Siches 3977, Ing. White ⚠

    # ── LABORATORIOS ───────────────────────────────────────────────────────
    'LAB-009': {'lat': -38.7398, 'lng': -62.2501},   # Avenente 3647, BB ⚠
    'LAB-022': {'lat': -38.7312, 'lng': -62.2489},   # Mascarello 3965, BB ⚠
    'LAB-023': {'lat': -38.7089, 'lng': -62.2698},   # J. M. Gutiérrez 270, BB ⚠
    'LAB-040': {'lat': -38.7015, 'lng': -62.2701},   # Sarmiento 2153, BB ⚠
    'LAB-041': {'lat': -38.7289, 'lng': -62.3102},   # Gurruchaga 226, BB ⚠
    'LAB-044': {'lat': -38.7198, 'lng': -62.2312},   # Av. Gral. Arias 2080, BB ⚠
    'LAB-047': {'lat': -38.7401, 'lng': -62.2589},   # Av. Lainez 1544, BB ⚠

    # ── UNIDADES SANITARIAS ────────────────────────────────────────────────
    'USA-001': {'lat': -38.7162, 'lng': -62.3341},   # 25 de Mayo 396, Gral. Cerri (C.S. Menghini) ⚠
    'USA-002': {'lat': -38.6987, 'lng': -62.2501},   # Adrián Veres y Martín Gil (C.S. Piñeiro) ⚠
    'USA-004': {'lat': -38.7234, 'lng': -62.2478},   # S. Mora y Malharro, BB ⚠
    'USA-005': {'lat': -38.7312, 'lng': -62.2398},   # Marechal y Remedios de Escalada (C.S. 9 de Nov.) ⚠
    'USA-006': {'lat': -38.8068, 'lng': -62.2701},   # Lautaro y Paul Harris, Ing. White (C.S. Capelli) ⚠
    'USA-033': {'lat': -38.6921, 'lng': -62.2489},   # Rufino Rojas 4898, BB ⚠
}

def main():
    with open(ARCHIVO, encoding='utf-8') as f:
        data = json.load(f)

    prestadores = data.get('prestadores', [])
    actualizados = 0
    no_encontrados = []

    for p in prestadores:
        pid = p.get('ID')
        if pid in COORDS and (not p.get('lat') or not p.get('lng')):
            p['lat'] = COORDS[pid]['lat']
            p['lng'] = COORDS[pid]['lng']
            actualizados += 1
            print(f"  ✓ {pid}: {p.get('PRESTADOR', p.get('NOMBRE', '?'))} → ({p['lat']}, {p['lng']})")

    for pid in COORDS:
        if not any(p.get('ID') == pid for p in prestadores):
            no_encontrados.append(pid)

    with open(ARCHIVO, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    print(f"\n{'='*55}")
    print(f"Actualizados: {actualizados}")
    print(f"Archivo guardado: {ARCHIVO}")

    if no_encontrados:
        print(f"\n⚠ IDs no encontrados en la BD (verificar): {no_encontrados}")

    print("""
⚠ IMPORTANTE: Las coords marcadas con ⚠ son aproximadas.
  Te recomiendo verificarlas en https://www.openstreetmap.org
  buscando la dirección y ajustando si es necesario.
  
  Las más críticas para verificar son las de Ing. White y Cerri
  ya que son localidades pequeñas donde un error de cuadra
  se nota más en el mapa.
""")

if __name__ == '__main__':
    main()
